# AI-Project-FI-UNAM
This is the final project for the Artificial Intelligence course of the UNAM Faculty of Engineering.

Link del sitio web de la implementación: https://infinite-crag-13775.herokuapp.com/
