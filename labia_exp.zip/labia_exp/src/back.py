#Import personality Insights SDK
from watson_developer_cloud import PersonalityInsightsV3
#import json
import json
#import googletrans
#from googletrans import Translator
#import pandas
import pandas as pd
#import webrowser
import webbrowser

url='https://api.us-south.personality-insights.watson.cloud.ibm.com/instances/c6aa4e32-e9be-4d4e-8ce3-8b8abf5aa155'
apikey='-P2pUTGEF30hXdiS4iUQH05400USV7imPKkZa9aN82Zq'
print('Iniciando...')
service = PersonalityInsightsV3(url=url, iam_apikey=apikey, version='2020-05-31')

def start(text):
	profile = service.profile(text, content_type = 'text/plain').get_result()
	x = convierte_df(action_back('personality',profile))
	y = convierte_df(action_back('needs',profile))
	z = convierte_df(action_back('values',profile))
	crea_html(x,y,z)
	return 0

def convierte_df(df_marks):
  html = df_marks.to_html()
  if html is None:
    html = DEFAULT_VALUE
  return html

def crea_html(p,n,v):
	f = open('gener.html','wb')
	mensaje = """<html><head></head><body><div><h1>Personalidad</h1>"""+str(p)+"""</div><div><h1>Necesidades</h1>"""+str(n)+"""</div><div><h1>Valores</h1>"""+str(v)+"""</div><!--Div that will hold the pie chart--><!--div id="chart_div"></div--></body></html>"""
	s = mensaje.encode()
	f.write(s)
	f.close()
	webbrowser.open_new_tab('gener.html')
	return 0
	
def action_back(name_insight, profile):
	insight = {p['name']:p['percentile'] for p in profile[name_insight]}
	df_insight = pd.DataFrame.from_dict(insight, orient='index')
	df_insight.reset_index(inplace=True)
	df_insight.columns=[name_insight,'percentile']
	return df_insight