from flask import Flask, render_template, request
#import asyncio
#import back

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/travel_text', methods=['POST'])
def travel_text():
    if request.method =='POST':
        textito = request.form['hola']
        back.start(textito)
        print(textito)
        return 'recived'

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)